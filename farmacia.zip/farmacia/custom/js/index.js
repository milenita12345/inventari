console.log('Archivo index.js encontrado y ejecutado correctamente.');


