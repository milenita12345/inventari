# Sistema de Gestión de Farmacia en PHP MySQL con Código Fuente
<img src="https://i0.wp.com/www.configuroweb.com/wp-content/uploads/2022/05/Sistema-de-Gestion-de-Farmacia-en-PHP-MySQL-con-Codigo-Fuente.png?resize=800%2C500&ssl=1">

Este Sistema de Gestión de Farmacia en PHP MySQL con Código Fuente le permite al usuario administrativo las siguientes opciones:

- Agregar, Listar, Editar y Eliminar Proveedores
- Agregar, Listar, Editar y Eliminar Categorías
- Agregar, Listar, Editar y Eliminar Medicinas
- Agregar, Listar, Editar, Eliminar e Imprimir Facturas
- Listar el Reporte de Ventas, Productos y Productos Vencidos por Periodos de Tiempo

Más información en el siguiente enlace: <a href="https://www.configuroweb.com/sistema-de-gestion-de-farmacia/">Sistema de Gestión de Farmacia en PHP MySQL con Código Fuente</a>
