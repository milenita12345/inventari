const path = require('path');  // Asegúrate de tener esta línea

module.exports = {
  entry: 'Farmacia./src/index.js',  // Asegúrate de que esta ruta sea correcta
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'dist')  // Utiliza la variable path aquí
  },
  mode: 'development',
  // otras configuraciones...
};


